package com.example.pdf.Pdfgeneration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfgenerationApplicationTests {

	@Test
	void contextLoads() {
	}

}
